'use server';
/**
 * @fileOverview An AI agent that synthesizes flashcards from study notes or documents.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AICardSynthesizerInputSchema = z.object({
  notes: z.string().describe('The study notes or document from which to generate flashcards.'),
});
export type AICardSynthesizerInput = z.infer<typeof AICardSynthesizerInputSchema>;

const FlashcardSchema = z.object({
  question: z.string().describe('The question for the front of the flashcard.'),
  answer: z.string().describe('The answer for the back of the flashcard.'),
});

const AICardSynthesizerOutputSchema = z.object({
  flashcards: z.array(FlashcardSchema).describe('A list of generated flashcards.'),
});
export type AICardSynthesizerOutput = z.infer<typeof AICardSynthesizerOutputSchema>;

export async function synthesizeFlashcards(
  input: AICardSynthesizerInput
): Promise<AICardSynthesizerOutput> {
  return aiCardSynthesizerFlow(input);
}

const flashcardSynthesizerPrompt = ai.definePrompt({
  name: 'flashcardSynthesizerPrompt',
  input: {schema: AICardSynthesizerInputSchema},
  output: {schema: AICardSynthesizerOutputSchema},
  prompt: `You are an expert in creating effective study materials, specializing in flashcards.
Your task is to analyze the provided study notes and extract key concepts to generate a set of concise and clear flashcards.
Each flashcard should have a distinct question on the front and a corresponding accurate answer on the back.

Here are the study notes:

Notes: {{{notes}}}

Please generate the flashcards in JSON format, strictly adhering to the schema.`,
});

const aiCardSynthesizerFlow = ai.defineFlow(
  {
    name: 'aiCardSynthesizerFlow',
    inputSchema: AICardSynthesizerInputSchema,
    outputSchema: AICardSynthesizerOutputSchema,
  },
  async input => {
    const {output} = await flashcardSynthesizerPrompt(input);
    if (!output) {
      throw new Error('Failed to generate flashcards.');
    }
    return output;
  }
);
