'use server';
/**
 * @fileOverview An AI agent that synthesizes flashcards from an image of study notes.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIScanNotesInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of study notes, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AIScanNotesInput = z.infer<typeof AIScanNotesInputSchema>;

const FlashcardSchema = z.object({
  question: z.string().describe('The question for the front of the flashcard.'),
  answer: z.string().describe('The answer for the back of the flashcard.'),
});

const AIScanNotesOutputSchema = z.object({
  flashcards: z.array(FlashcardSchema).describe('A list of generated flashcards.'),
});
export type AIScanNotesOutput = z.infer<typeof AIScanNotesOutputSchema>;

export async function scanNotesForCards(
  input: AIScanNotesInput
): Promise<AIScanNotesOutput> {
  return aiScanNotesFlow(input);
}

const scanNotesPrompt = ai.definePrompt({
  name: 'scanNotesPrompt',
  input: {schema: AIScanNotesInputSchema},
  output: {schema: AIScanNotesOutputSchema},
  prompt: `You are an expert OCR and study material synthesizer.
Look at the provided image of study notes. Your task is to extract the key educational concepts and transform them into a set of effective, concise flashcards.
Ensure the flashcards cover the most important definitions, formulas, or facts found in the image.

Image: {{media url=photoDataUri}}

Please generate the flashcards in JSON format, strictly adhering to the schema.`,
});

const aiScanNotesFlow = ai.defineFlow(
  {
    name: 'aiScanNotesFlow',
    inputSchema: AIScanNotesInputSchema,
    outputSchema: AIScanNotesOutputSchema,
  },
  async input => {
    const {output} = await scanNotesPrompt(input);
    if (!output) {
      throw new Error('Failed to extract flashcards from the image.');
    }
    return output;
  }
);
