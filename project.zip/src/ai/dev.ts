import { config } from 'dotenv';
config();

import '@/ai/flows/ai-card-synthesizer.ts';
import '@/ai/flows/ai-scan-notes.ts';
