"use client"

import { useState, useEffect, useCallback } from 'react';
import { Deck, Flashcard } from '@/lib/types';

const STORAGE_KEY = 'recallify_decks_v1';

export function useDecks() {
  const [decks, setDecks] = useState<Deck[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setDecks(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load decks", e);
      }
    }
    setIsLoaded(true);
  }, []);

  const saveDecks = useCallback((newDecks: Deck[] | ((prev: Deck[]) => Deck[])) => {
    setDecks((prev) => {
      const updated = typeof newDecks === 'function' ? newDecks(prev) : newDecks;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const addDeck = (name: string, category: string) => {
    const newDeck: Deck = {
      id: Math.random().toString(36).substring(7),
      name,
      category,
      cards: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveDecks((prev) => [...prev, newDeck]);
    return newDeck;
  };

  const updateDeck = (deckId: string, updates: Partial<Deck>) => {
    saveDecks((prev) => 
      prev.map(d => d.id === deckId ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d)
    );
  };

  const deleteDeck = (deckId: string) => {
    saveDecks((prev) => prev.filter(d => d.id !== deckId));
  };

  const addCardsToDeck = (deckId: string, newCards: Omit<Flashcard, 'id' | 'masteryLevel'>[]) => {
    const cardsToAdd: Flashcard[] = newCards.map(c => ({
      ...c,
      id: Math.random().toString(36).substring(7),
      masteryLevel: 0,
    }));

    saveDecks((prev) => 
      prev.map(deck => {
        if (deck.id === deckId) {
          return {
            ...deck,
            cards: [...deck.cards, ...cardsToAdd],
            updatedAt: new Date().toISOString()
          };
        }
        return deck;
      })
    );
  };

  const updateCardMastery = (deckId: string, cardId: string, confidence: number) => {
    saveDecks((prev) => 
      prev.map(deck => {
        if (deck.id === deckId) {
          const updatedCards = deck.cards.map(c => 
            c.id === cardId ? { ...c, masteryLevel: confidence, lastStudied: new Date().toISOString() } : c
          );
          return { ...deck, cards: updatedCards, updatedAt: new Date().toISOString() };
        }
        return deck;
      })
    );
  };

  return {
    decks,
    isLoaded,
    addDeck,
    updateDeck,
    deleteDeck,
    addCardsToDeck,
    updateCardMastery
  };
}
