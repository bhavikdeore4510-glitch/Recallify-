"use client"

import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';

interface Flashcard3DProps {
  question: string;
  answer: string;
  isFlipped: boolean;
  onFlip: () => void;
}

export function Flashcard3D({ question, answer, isFlipped, onFlip }: Flashcard3DProps) {
  return (
    <div 
      className="relative w-full max-w-xl aspect-[4/3] perspective-1000 cursor-pointer"
      onClick={onFlip}
    >
      <div className={cn(
        "flashcard-inner w-full h-full preserve-3d relative duration-700",
        isFlipped && "rotate-y-180"
      )}>
        {/* Front */}
        <Card className="absolute inset-0 w-full h-full backface-hidden shadow-xl border-2 hover:border-accent transition-colors">
          <CardContent className="flex flex-col items-center justify-center h-full p-12 text-center">
            <span className="text-xs font-bold tracking-widest text-muted-foreground uppercase mb-4">Question</span>
            <p className="text-2xl font-medium leading-relaxed font-body">{question}</p>
            <span className="absolute bottom-6 text-sm text-muted-foreground animate-pulse">Tap to flip</span>
          </CardContent>
        </Card>

        {/* Back */}
        <Card className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 shadow-xl border-2 border-accent/20 bg-secondary/30">
          <CardContent className="flex flex-col items-center justify-center h-full p-12 text-center overflow-auto">
            <span className="text-xs font-bold tracking-widest text-secondary-foreground uppercase mb-4">Answer</span>
            <div className="prose prose-sm max-w-none">
              <p className="text-xl leading-relaxed font-body">{answer}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
