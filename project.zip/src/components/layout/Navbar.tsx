
"use client"

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { BookOpen, Trophy, Zap, LayoutDashboard, User, LogOut } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useUser, useAuth, useFirestore, useDoc } from '@/firebase';
import { signOut } from 'firebase/auth';
import { doc } from 'firebase/firestore';
import { useMemoFirebase } from '@/firebase/use-memo-firebase';

export function Navbar() {
  const router = useRouter();
  const { user, loading } = useUser();
  const auth = useAuth();
  const db = useFirestore();

  // Fetch points from Firestore profile if user exists
  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, 'users', user.uid);
  }, [db, user]);

  const { data: profile } = useDoc(profileRef);

  const handleSignOut = async () => {
    if (auth) {
      await signOut(auth);
      router.push('/');
    }
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-primary p-2 rounded-lg text-white transform group-hover:rotate-12 transition-transform">
            <BookOpen className="w-5 h-5" />
          </div>
          <span className="font-headline text-xl font-bold text-primary">Recallify</span>
        </Link>
        
        <div className="hidden md:flex items-center gap-6">
          <Link href="/decks" className="text-sm font-medium hover:text-accent transition-colors flex items-center gap-1.5">
             <BookOpen className="w-4 h-4" /> My Decks
          </Link>
          <Link href="/dashboard" className="text-sm font-medium hover:text-accent transition-colors flex items-center gap-1.5">
            <LayoutDashboard className="w-4 h-4" /> Profile & Stats
          </Link>
          <Link href="/leaderboard" className="text-sm font-medium hover:text-accent transition-colors flex items-center gap-1.5">
            <Trophy className="w-4 h-4" /> Hall of Fame
          </Link>
        </div>

        <div className="flex items-center gap-3">
          {!loading && user ? (
            <>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-yellow-50 rounded-full border border-yellow-200 cursor-default">
                      <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-sm font-bold text-yellow-700">
                        {profile?.totalPoints?.toLocaleString() || '0'}
                      </span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Global Study Points</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar className="h-9 w-9 cursor-pointer ring-2 ring-primary/10 transition-all hover:ring-primary/30">
                    <AvatarImage src={user.photoURL || undefined} />
                    <AvatarFallback>{user.displayName?.[0] || 'U'}</AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="font-bold truncate">{user.displayName || 'Learner'}</div>
                    <div className="text-xs text-muted-foreground truncate">{user.email}</div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="cursor-pointer">
                      <User className="w-4 h-4 mr-2" /> My Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/leaderboard" className="cursor-pointer">
                      <Trophy className="w-4 h-4 mr-2" /> Leaderboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive focus:text-destructive cursor-pointer"
                    onSelect={handleSignOut}
                  >
                    <LogOut className="w-4 h-4 mr-2" /> Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button asChild variant="default" size="sm">
              <Link href="/login">Sign In</Link>
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
}
