
export type Flashcard = {
  id: string;
  question: string;
  answer: string;
  masteryLevel: number; // 0-3 (New, Learning, Mastering, Mastered)
  lastStudied?: string;
};

export type Deck = {
  id: string;
  name: string;
  category: string;
  cards: Flashcard[];
  createdAt: string;
  updatedAt: string;
};

export type UserProfile = {
  uid: string;
  displayName: string;
  photoURL?: string;
  totalPoints: number;
  cardsStudiedCount: number;
  masteryCount: number;
  lastActive: string;
};

export type StudySession = {
  id: string;
  deckId: string;
  startTime: string;
  endTime?: string;
  cardsStudied: number;
  confidenceRatings: Record<string, number>;
};
