
"use client"

import { Navbar } from '@/components/layout/Navbar';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Zap, Trophy, ShieldCheck, LayoutDashboard, ArrowRight } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function Home() {
  const router = useRouter();

  const handleStart = () => {
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative py-20 overflow-hidden bg-white">
          <div className="container mx-auto px-4 relative z-10 text-center">
            <Badge variant="secondary" className="mb-6 px-4 py-1.5 rounded-full text-accent bg-accent/10 border-accent/20">
              <Sparkles className="w-4 h-4 mr-2" /> AI-Powered Active Recall
            </Badge>
            <h1 className="text-5xl md:text-7xl font-headline font-bold text-primary mb-6 leading-tight">
              Master Any Subject with Scientific Precision
            </h1>
            <p className="text-xl text-muted-foreground mb-10 leading-relaxed max-w-2xl mx-auto">
              Recallify turns your study notes into powerful flashcards using AI. 
              Leverage active recall and spaced repetition to achieve academic excellence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleStart}
                size="lg" 
                className="h-14 px-8 text-lg gap-2 shadow-xl hover:shadow-2xl transition-all"
              >
                Get Started
                <ArrowRight className="w-5 h-5" />
              </Button>
              <Button onClick={() => router.push('/leaderboard')} variant="outline" size="lg" className="h-14 px-8 text-lg gap-2">
                <Trophy className="w-5 h-5" /> View Leaderboard
              </Button>
            </div>
          </div>
          
          <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        </section>

        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-sm ring-1 ring-border p-6 hover:ring-accent/30 transition-all">
                <div className="bg-accent/10 p-3 rounded-xl w-fit mb-4">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-xl font-bold mb-2">AI Synthesis</h3>
                <p className="text-muted-foreground">Convert messy notes or PDF text into structured flashcards in seconds.</p>
              </Card>
              <Card className="border-none shadow-sm ring-1 ring-border p-6 hover:ring-primary/30 transition-all">
                <div className="bg-primary/10 p-3 rounded-xl w-fit mb-4">
                  <ShieldCheck className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Verified Retention</h3>
                <p className="text-muted-foreground">Scientifically proven methods to increase memory retention by up to 300%.</p>
              </Card>
              <Card className="border-none shadow-sm ring-1 ring-border p-6 hover:ring-yellow-500/30 transition-all">
                <div className="bg-yellow-100 p-3 rounded-xl w-fit mb-4">
                  <Trophy className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Global Rankings</h3>
                <p className="text-muted-foreground">Earn points for every session and climb the global leaderboard with friends.</p>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
