
"use client"

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useDecks } from '@/hooks/use-decks';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Plus, BookOpen, Clock, Trash2, Pencil, Loader2 } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useUser } from '@/firebase';

export default function DecksPage() {
  const { decks, isLoaded, deleteDeck } = useDecks();
  const { user, loading: authLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  if (!isLoaded || authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-12 flex flex-col items-center justify-center min-h-[60vh]">
          <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
          <p className="text-muted-foreground font-medium animate-pulse">Preparing your library...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 md:py-12">
        <header className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-4xl font-headline font-bold text-primary">My Decks</h1>
              <Badge variant="outline" className="font-bold border-primary/20 text-primary">
                {decks.length} TOTAL
              </Badge>
            </div>
            <p className="text-muted-foreground text-lg">Select a subject and push your memory to the limit.</p>
          </div>
          <Button asChild size="lg" className="gap-2 shadow-lg hover:shadow-xl transition-shadow">
            <Link href="/create">
              <Plus className="w-5 h-5" /> Create New Deck
            </Link>
          </Button>
        </header>

        {decks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 bg-white rounded-3xl border border-border shadow-sm overflow-hidden text-center">
            <div className="relative w-full max-w-sm aspect-video mb-8 rounded-2xl overflow-hidden ring-1 ring-border">
              <Image 
                src="https://picsum.photos/seed/recallify-study/800/600" 
                alt="Student studying"
                fill
                className="object-cover"
                data-ai-hint="student studying"
              />
            </div>
            <h2 className="text-3xl font-headline font-bold mb-3 text-primary">Your library is empty</h2>
            <p className="text-muted-foreground mb-8 max-w-md text-center text-lg px-4">
              Unlock your potential with active recall. Create your first flashcard deck manually or use AI to synthesize notes.
            </p>
            <Button asChild size="lg" className="px-10 h-14 text-lg gap-2">
              <Link href="/create">
                <Plus className="w-5 h-5" /> Create First Deck
              </Link>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {decks.map((deck) => (
              <Card key={deck.id} className="group hover:shadow-xl transition-all duration-300 border-none shadow-sm ring-1 ring-border bg-white overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <Badge variant="secondary" className="mb-2 font-body font-medium">{deck.category}</Badge>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => deleteDeck(deck.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <CardTitle className="text-xl font-headline">{deck.name}</CardTitle>
                </CardHeader>
                <CardContent className="pb-6">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground font-body">
                    <div className="flex items-center gap-1">
                      <BookOpen className="w-4 h-4" />
                      {deck.cards.length} cards
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Updated {new Date(deck.updatedAt).toLocaleDateString()}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 flex gap-2">
                  {deck.cards.length > 0 ? (
                    <Button asChild className="flex-1 gap-2 bg-primary hover:bg-primary/90">
                      <Link href={`/decks/${deck.id}/study`}>
                        <Play className="w-4 h-4" fill="currentColor" /> Study Now
                      </Link>
                    </Button>
                  ) : (
                    <Button 
                      asChild
                      variant="secondary"
                      className="flex-1 gap-2 border-dashed border-2 bg-transparent border-primary/20 text-primary hover:bg-primary/5"
                    >
                      <Link href={`/decks/${deck.id}`}>
                        <Plus className="w-4 h-4" /> Add Cards First
                      </Link>
                    </Button>
                  )}
                  <Button asChild variant="outline" size="icon" className="shrink-0">
                    <Link href={`/decks/${deck.id}`}>
                      <Pencil className="w-4 h-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
