
"use client"

import { useState, useMemo, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useDecks } from '@/hooks/use-decks';
import { Navbar } from '@/components/layout/Navbar';
import { Flashcard3D } from '@/components/flashcard/Flashcard3D';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  CheckCircle2, 
  HelpCircle, 
  XCircle, 
  ChevronLeft, 
  RefreshCcw,
  Trophy,
  Loader2
} from 'lucide-react';
import Link from 'next/link';
import { useUser, useFirestore, errorEmitter, FirestorePermissionError } from '@/firebase';
import { doc, setDoc, increment } from 'firebase/firestore';

export default function StudyPage() {
  const { id } = useParams() as { id: string };
  const router = useRouter();
  const { decks, isLoaded, updateCardMastery } = useDecks();
  const { user } = useUser();
  const db = useFirestore();
  
  const deck = useMemo(() => decks.find(d => d.id === id), [decks, id]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [sessionComplete, setSessionComplete] = useState(false);
  const [confidenceData, setConfidenceData] = useState<Record<string, number>>({});
  const [pointsEarned, setPointsEarned] = useState(0);

  useEffect(() => {
    if (isLoaded && (!deck || deck.cards.length === 0)) {
      router.push('/');
    }
  }, [isLoaded, deck, router]);

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container max-w-4xl mx-auto px-4 py-20 flex flex-col items-center">
           <Loader2 className="w-10 h-10 animate-spin text-primary" />
           <p className="mt-4 text-muted-foreground font-medium">Preparing session...</p>
        </main>
      </div>
    );
  }

  if (!deck || deck.cards.length === 0) return null;

  const currentCard = deck.cards[currentIndex];
  const progress = ((currentIndex) / deck.cards.length) * 100;

  const handleConfidence = (score: number) => {
    if (!currentCard) return;

    setConfidenceData(prev => ({ ...prev, [currentCard.id]: score }));
    updateCardMastery(deck.id, currentCard.id, score);

    const points = score === 3 ? 30 : 10;
    setPointsEarned(prev => prev + points);

    if (currentIndex < deck.cards.length - 1) {
      setIsFlipped(false);
      setTimeout(() => {
        setCurrentIndex(currentIndex + 1);
      }, 300);
    } else {
      finalizeSession();
    }
  };

  const finalizeSession = () => {
    setSessionComplete(true);
    
    // Attempt to persist if firestore is ready, otherwise just local
    if (db) {
      const uid = user?.uid || "mock-user-" + (localStorage.getItem('recallify_user_email') || 'bhavik');
      const userRef = doc(db, 'users', uid);
      const masteryCount = Object.values(confidenceData).filter(v => v === 3).length;
      const totalPointsThisSession = pointsEarned + (masteryCount === deck.cards.length ? 50 : 0);
      const displayName = localStorage.getItem('recallify_user_name') || 'Bhavik Deore';

      setDoc(userRef, {
        uid: uid,
        displayName: displayName,
        photoURL: localStorage.getItem('recallify_user_image') || '',
        totalPoints: increment(totalPointsThisSession),
        cardsStudiedCount: increment(deck.cards.length),
        masteryCount: increment(masteryCount),
        lastActive: new Date().toISOString()
      }, { merge: true })
        .catch(async (err) => {
          const permissionError = new FirestorePermissionError({
            path: userRef.path,
            operation: 'write',
            requestResourceData: { totalPoints: totalPointsThisSession }
          });
          errorEmitter.emit('permission-error', permissionError);
        });
    }
  };

  const restart = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setSessionComplete(false);
    setConfidenceData({});
    setPointsEarned(0);
  };

  if (sessionComplete) {
    const masteredCount = Object.values(confidenceData).filter(v => v === 3).length;
    const bonus = masteredCount === deck.cards.length ? 50 : 0;

    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="bg-white p-12 rounded-3xl shadow-xl ring-1 ring-border border-none">
            <div className="mb-6 inline-flex p-6 bg-accent/10 rounded-full">
              <Trophy className="w-16 h-16 text-accent" />
            </div>
            <h1 className="text-4xl font-headline font-bold text-primary mb-2">Session Complete!</h1>
            <p className="text-muted-foreground text-lg mb-4">You studied {deck.cards.length} cards in {deck.name}.</p>
            
            <div className="flex flex-col items-center mb-8">
              <div className="text-5xl font-black text-primary">+{pointsEarned + bonus}</div>
              <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground mt-1">Study Points Earned</div>
              {bonus > 0 && <div className="text-xs font-bold text-yellow-600 mt-1">(Includes +50 Mastery Bonus!)</div>}
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-10">
              <div className="bg-secondary/50 p-4 rounded-xl">
                <div className="text-2xl font-bold text-primary">{masteredCount}</div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Mastered</div>
              </div>
              <div className="bg-secondary/50 p-4 rounded-xl">
                <div className="text-2xl font-bold text-primary">{Object.values(confidenceData).filter(v => v === 2).length}</div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Learning</div>
              </div>
              <div className="bg-secondary/50 p-4 rounded-xl">
                <div className="text-2xl font-bold text-primary">{Object.values(confidenceData).filter(v => v < 2).length}</div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Forgot</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gap-2" onClick={restart}>
                <RefreshCcw className="w-5 h-5" /> Study Again
              </Button>
              <Link href="/">
                <Button variant="outline" size="lg">Back to Decks</Button>
              </Link>
            </div>
            
            <p className="mt-8 text-sm text-green-600 font-medium">Progress saved to your academic profile.</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8 md:py-12 flex flex-col items-center">
        <div className="w-full flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2 text-muted-foreground">
              <ChevronLeft className="w-4 h-4" /> Exit Session
            </Button>
          </Link>
          <div className="text-sm font-bold font-body text-primary uppercase tracking-widest">
            Card {currentIndex + 1} of {deck.cards.length}
          </div>
          <div className="w-32">
             <Progress value={progress} className="h-2" />
          </div>
        </div>

        <Flashcard3D 
          question={currentCard.question} 
          answer={currentCard.answer} 
          isFlipped={isFlipped}
          onFlip={() => setIsFlipped(!isFlipped)}
        />

        <div className="mt-12 w-full max-w-xl transition-all duration-500 ease-in-out">
          {!isFlipped ? (
            <div className="text-center space-y-4">
              <p className="text-muted-foreground">Think of the answer, then flip to reveal.</p>
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full h-16 text-lg border-2"
                onClick={() => setIsFlipped(true)}
              >
                Show Answer
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-center font-bold text-primary uppercase tracking-widest text-sm">Rate Your Confidence</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="flex flex-col h-auto py-6 gap-2 border-2 hover:border-destructive hover:bg-destructive/5"
                  onClick={() => handleConfidence(1)}
                >
                  <XCircle className="w-8 h-8 text-destructive" />
                  <div className="flex flex-col items-center">
                    <span className="font-bold">Forgot</span>
                    <span className="text-xs text-muted-foreground">Try again later</span>
                  </div>
                </Button>
                
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="flex flex-col h-auto py-6 gap-2 border-2 hover:border-yellow-500 hover:bg-yellow-50"
                  onClick={() => handleConfidence(2)}
                >
                  <HelpCircle className="w-8 h-8 text-yellow-500" />
                  <div className="flex flex-col items-center">
                    <span className="font-bold">Unsure</span>
                    <span className="text-xs text-muted-foreground">Needs review</span>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  size="lg" 
                  className="flex flex-col h-auto py-6 gap-2 border-2 hover:border-green-500 hover:bg-green-50"
                  onClick={() => handleConfidence(3)}
                >
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
                  <div className="flex flex-col items-center">
                    <span className="font-bold">Mastered</span>
                    <span className="text-xs text-muted-foreground">Got it perfectly</span>
                  </div>
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
