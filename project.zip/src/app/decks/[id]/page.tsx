
"use client"

import { useState, useMemo, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useDecks } from '@/hooks/use-decks';
import { Navbar } from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Trash2, Save, ChevronLeft, Pencil, BookOpen, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import Link from 'next/link';

export default function DeckEditorPage() {
  const { id } = useParams() as { id: string };
  const router = useRouter();
  const { decks, isLoaded, updateDeck } = useDecks();
  
  const deck = useMemo(() => decks.find(d => d.id === id), [decks, id]);
  const [newQuestion, setNewQuestion] = useState('');
  const [newAnswer, setNewAnswer] = useState('');
  const [editingTitle, setEditingTitle] = useState(false);
  const [deckName, setDeckName] = useState('');

  useEffect(() => {
    if (isLoaded && !deck) {
      router.push('/');
    } else if (deck) {
      setDeckName(deck.name);
    }
  }, [isLoaded, deck, router]);

  if (!isLoaded || !deck) return null;

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestion || !newAnswer) return;
    
    const newCard = {
      id: Math.random().toString(36).substring(7),
      question: newQuestion,
      answer: newAnswer,
      masteryLevel: 0,
    };

    updateDeck(deck.id, { cards: [...deck.cards, newCard] });
    setNewQuestion('');
    setNewAnswer('');
  };

  const deleteCard = (cardId: string) => {
    updateDeck(deck.id, { cards: deck.cards.filter(c => c.id !== cardId) });
  };

  const saveDeckName = () => {
    updateDeck(deck.id, { name: deckName });
    setEditingTitle(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container max-w-5xl mx-auto px-4 py-12">
        <header className="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex-1">
            <Button asChild variant="ghost" className="mb-4 -ml-4 gap-2 text-muted-foreground">
              <Link href="/">
                <ChevronLeft className="w-4 h-4" /> Back to My Decks
              </Link>
            </Button>
            
            {editingTitle ? (
              <div className="flex items-center gap-2 max-w-md">
                <Input 
                  value={deckName} 
                  onChange={(e) => setDeckName(e.target.value)} 
                  className="text-3xl font-headline font-bold h-14"
                />
                <Button size="icon" className="h-14 w-14 shrink-0" onClick={saveDeckName}><Save className="w-6 h-6" /></Button>
              </div>
            ) : (
              <div className="flex items-center gap-4 group">
                <h1 className="text-4xl font-headline font-bold text-primary">{deck.name}</h1>
                <Button variant="ghost" size="icon" onClick={() => { setEditingTitle(true); }}>
                  <Pencil className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
              </div>
            )}
            <p className="text-muted-foreground mt-2">{deck.category} • {deck.cards.length} cards</p>
          </div>
          
          {deck.cards.length > 0 ? (
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 shadow-md gap-2">
              <Link href={`/decks/${deck.id}/study`}>
                <BookOpen className="w-5 h-5" /> Start Studying
              </Link>
            </Button>
          ) : (
            <Button size="lg" className="bg-primary hover:bg-primary/90 shadow-md gap-2" disabled>
              <BookOpen className="w-5 h-5" /> Start Studying
            </Button>
          )}
        </header>

        {deck.cards.length === 0 && (
          <Alert className="mb-8 bg-accent/5 border-accent/20">
            <AlertCircle className="h-4 w-4 text-accent" />
            <AlertTitle className="text-accent font-bold">Deck is Empty</AlertTitle>
            <AlertDescription>
              Add at least one card below to start your study session. You can use AI to synthesize cards from your notes in the creation menu if you prefer.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <section className="lg:col-span-1">
            <Card className="sticky top-24 border-none shadow-sm ring-1 ring-border">
              <CardContent className="pt-6">
                <h2 className="text-xl font-headline font-bold mb-4 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-accent" /> Add New Card
                </h2>
                <form onSubmit={handleAddCard} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="question">Question (Front)</Label>
                    <Textarea 
                      id="question" 
                      placeholder="e.g. What is Active Recall?" 
                      value={newQuestion}
                      onChange={(e) => setNewQuestion(e.target.value)}
                      className="min-h-[100px]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="answer">Answer (Back)</Label>
                    <Textarea 
                      id="answer" 
                      placeholder="Enter the detailed answer..." 
                      value={newAnswer}
                      onChange={(e) => setNewAnswer(e.target.value)}
                      className="min-h-[150px]"
                    />
                  </div>
                  <Button type="submit" className="w-full h-12 bg-accent hover:bg-accent/90 shadow-md">
                    Add Card to Deck
                  </Button>
                </form>
              </CardContent>
            </Card>
          </section>

          <section className="lg:col-span-2 space-y-4">
            <h2 className="text-xl font-headline font-bold mb-4">Deck Contents</h2>
            {deck.cards.length === 0 ? (
              <div className="bg-white p-12 rounded-xl text-center border-2 border-dashed border-muted text-muted-foreground">
                No cards in this deck yet. Add one using the form.
              </div>
            ) : (
              [...deck.cards].reverse().map((card, idx) => (
                <Card key={card.id} className="group overflow-hidden border-none shadow-sm ring-1 ring-border transition-all hover:ring-accent/30">
                  <CardContent className="p-0 flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x">
                    <div className="flex-1 p-6 bg-white">
                      <div className="text-xs font-bold text-muted-foreground uppercase mb-2 tracking-widest">Question {deck.cards.length - idx}</div>
                      <p className="font-medium text-lg leading-relaxed">{card.question}</p>
                    </div>
                    <div className="flex-1 p-6 bg-secondary/10">
                      <div className="flex justify-between items-start mb-2">
                        <div className="text-xs font-bold text-secondary-foreground uppercase tracking-widest">Answer</div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => deleteCard(card.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{card.answer}</p>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
