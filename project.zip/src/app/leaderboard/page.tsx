"use client"

import { useCollection } from '@/firebase';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Star, Target, Loader2, Sparkles, TrendingUp, ChevronLeft } from 'lucide-react';
import { useFirestore, useUser } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { useMemoFirebase } from '@/firebase/use-memo-firebase';
import { UserProfile } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

export default function LeaderboardPage() {
  const router = useRouter();
  const db = useFirestore();
  const { user: currentUser } = useUser();
  
  const leaderboardQuery = useMemoFirebase(() => {
    if (!db) return null;
    return query(
      collection(db, 'users'),
      orderBy('totalPoints', 'desc'),
      limit(25)
    );
  }, [db]);

  const { data: users, loading } = useCollection<UserProfile>(leaderboardQuery);

  const getRankDecoration = (index: number) => {
    switch (index) {
      case 0: return { icon: <Trophy className="w-8 h-8 text-yellow-500" />, border: "ring-2 ring-yellow-400 bg-yellow-50/50", badge: "Legendary Scholar" };
      case 1: return { icon: <Medal className="w-7 h-7 text-slate-400" />, border: "ring-2 ring-slate-300 bg-slate-50/50", badge: "Elite Academic" };
      case 2: return { icon: <Medal className="w-7 h-7 text-amber-700" />, border: "ring-2 ring-amber-400 bg-amber-50/50", badge: "High Achiever" };
      default: return { icon: <span className="text-lg font-bold text-muted-foreground">#{index + 1}</span>, border: "ring-1 ring-border", badge: null };
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container max-w-4xl mx-auto px-4 py-12">
        <header className="mb-12 text-center relative">
          <div className="absolute left-0 top-0">
             <Button 
                variant="ghost" 
                onClick={() => router.push('/')} 
                className="gap-2 text-muted-foreground hover:text-primary transition-colors"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </Button>
          </div>
          
          <Badge className="mb-4 px-4 py-1 bg-accent/10 text-accent border-accent/20">
            <Sparkles className="w-3 h-3 mr-2" /> Global Rankings
          </Badge>
          <h1 className="text-6xl font-headline font-bold text-primary mb-4">The Hall of Fame</h1>
          <p className="text-muted-foreground text-lg max-w-lg mx-auto leading-relaxed">
            Honoring the students who turn focus into mastery. Keep studying to climb the ranks.
          </p>
        </header>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <p className="text-muted-foreground font-medium">Fetching top achievers...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {users?.map((user, index) => {
              const deco = getRankDecoration(index);
              const isMe = user.uid === currentUser?.uid;
              
              return (
                <Card 
                  key={user.uid} 
                  className={cn(
                    "border-none shadow-sm ring-1 transition-all duration-300",
                    deco.border,
                    index < 3 ? "scale-[1.02] shadow-md" : "hover:shadow-md hover:scale-[1.01]",
                    isMe && "ring-primary bg-primary/5"
                  )}
                >
                  <CardContent className="p-5 flex items-center gap-6">
                    <div className="w-14 flex justify-center items-center">
                      {deco.icon}
                    </div>
                    
                    <Avatar className="h-14 w-14 border-2 border-white shadow-sm ring-1 ring-primary/5">
                      <AvatarImage src={user.photoURL} />
                      <AvatarFallback>{user.displayName?.[0] || 'U'}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3">
                        <h3 className="font-bold text-xl truncate">
                          {user.displayName} {isMe && <span className="text-sm font-normal text-muted-foreground">(You)</span>}
                        </h3>
                        {deco.badge && (
                          <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-tighter h-5 px-2">
                            {deco.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1.5 font-medium">
                        <span className="flex items-center gap-1.5">
                          <Target className="w-3.5 h-3.5" /> {user.masteryCount || 0} Concepts Mastered
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Target className="w-3.5 h-3.5 text-green-600" /> {user.cardsStudiedCount || 0} Total Cards
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-3xl font-black text-primary leading-none tabular-nums">
                        {user.totalPoints?.toLocaleString() || 0}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mt-1">Study Points</div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {users?.length === 0 && (
              <div className="text-center py-24 bg-white rounded-3xl ring-1 ring-border shadow-inner">
                <Trophy className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-primary mb-2">No rankings yet</h2>
                <p className="text-muted-foreground">Start your first study session to claim your place on the board!</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
