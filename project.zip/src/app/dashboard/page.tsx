
"use client"

import { useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useDecks } from '@/hooks/use-decks';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Brain, Target, Zap, Clock, Trophy, Calendar, Mail, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser, useFirestore, useDoc } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useMemoFirebase } from '@/firebase/use-memo-firebase';

export default function DashboardPage() {
  const router = useRouter();
  const { decks, isLoaded: decksLoaded } = useDecks();
  const { user, loading: authLoading } = useUser();
  const db = useFirestore();

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, 'users', user.uid);
  }, [db, user]);

  const { data: profile, loading: profileLoading } = useDoc(profileRef);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const stats = useMemo(() => {
    let totalCards = 0;
    let masteredCount = 0;
    let learningCount = 0;
    let newCount = 0;

    decks.forEach(deck => {
      deck.cards.forEach(card => {
        totalCards++;
        if (card.masteryLevel === 3) masteredCount++;
        else if (card.masteryLevel > 0) learningCount++;
        else newCount++;
      });
    });

    const masteryData = [
      { name: 'Mastered', value: masteredCount, color: '#2B7EA1' },
      { name: 'Learning', value: learningCount, color: '#3A4C8B' },
      { name: 'New', value: newCount, color: '#E2E8F0' },
    ];

    const deckData = decks.map(d => ({
      name: d.name.length > 12 ? d.name.substring(0, 10) + '...' : d.name,
      count: d.cards.length,
      mastered: d.cards.filter(c => c.masteryLevel === 3).length
    })).slice(0, 8);

    return { totalCards, masteredCount, masteryData, deckData };
  }, [decks]);

  if (authLoading || !user || !decksLoaded) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container max-w-6xl mx-auto px-4 py-12 flex justify-center">
          <div className="animate-pulse flex flex-col items-center gap-4">
             <div className="h-12 w-48 bg-muted rounded"></div>
             <div className="h-64 w-full max-w-4xl bg-muted rounded-xl mt-8"></div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container max-w-6xl mx-auto px-4 py-12">
        <header className="mb-10">
          <Button 
            variant="ghost" 
            onClick={() => router.push('/decks')} 
            className="mb-4 -ml-4 gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ChevronLeft className="w-4 h-4" /> Back to My Decks
          </Button>
          <h1 className="text-4xl font-headline font-bold text-primary mb-2">Academic Profile</h1>
          <p className="text-muted-foreground text-lg">Your progress, achievements, and retention metrics.</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
          {/* Profile Card */}
          <Card className="lg:col-span-1 border-none shadow-md ring-1 ring-border bg-white overflow-hidden h-fit">
            <div className="h-24 bg-primary relative">
               <div className="absolute -bottom-12 left-6">
                  <Avatar className="h-24 w-24 border-4 border-white shadow-lg">
                    <AvatarImage src={user.photoURL || undefined} />
                    <AvatarFallback className="text-2xl">{user.displayName?.[0]}</AvatarFallback>
                  </Avatar>
               </div>
            </div>
            <CardContent className="pt-16 space-y-4">
               <div>
                  <h2 className="text-xl font-bold">{user.displayName}</h2>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                    <Mail className="w-3 h-3" /> {user.email}
                  </div>
               </div>
               
               <Separator />
               
               <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2"><Calendar className="w-4 h-4" /> Member Since</span>
                    <span className="font-medium">March 2024</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2"><Clock className="w-4 h-4" /> Last Active</span>
                    <span className="font-medium">
                      {profile?.lastActive ? new Date(profile.lastActive).toLocaleDateString() : 'Today'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2"><Trophy className="w-4 h-4 text-yellow-500" /> Rank Tier</span>
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-none font-bold">
                       {profile?.totalPoints > 1000 ? "Expert" : "Novice"}
                    </Badge>
                  </div>
               </div>
            </CardContent>
          </Card>

          {/* Stats Grid */}
          <div className="lg:col-span-3 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-none shadow-sm ring-1 ring-border">
                <CardContent className="pt-6 flex flex-col items-center text-center gap-2">
                  <div className="p-2 bg-yellow-100 rounded-lg"><Trophy className="w-5 h-5 text-yellow-600" /></div>
                  <div>
                    <div className="text-2xl font-black text-primary">
                      {profile?.totalPoints?.toLocaleString() || '0'}
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Study Points</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm ring-1 ring-border">
                <CardContent className="pt-6 flex flex-col items-center text-center gap-2">
                  <div className="p-2 bg-primary/10 rounded-lg"><Brain className="w-5 h-5 text-primary" /></div>
                  <div>
                    <div className="text-2xl font-black text-primary">{stats.totalCards}</div>
                    <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Library Cards</div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-none shadow-sm ring-1 ring-border">
                <CardContent className="pt-6 flex flex-col items-center text-center gap-2">
                  <div className="p-2 bg-accent/10 rounded-lg"><Target className="w-5 h-5 text-accent" /></div>
                  <div>
                    <div className="text-2xl font-black text-primary">{stats.masteredCount}</div>
                    <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Mastered</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm ring-1 ring-border">
                <CardContent className="pt-6 flex flex-col items-center text-center gap-2">
                  <div className="p-2 bg-green-100 rounded-lg"><Zap className="w-5 h-5 text-green-600" /></div>
                  <div>
                    <div className="text-2xl font-black text-primary">
                      {stats.totalCards ? Math.round((stats.masteredCount / stats.totalCards) * 100) : 0}%
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Proficiency</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="border-none shadow-sm ring-1 ring-border h-[350px]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Mastery Distribution</CardTitle>
                </CardHeader>
                <CardContent className="h-full pb-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stats.masteryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={90}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {stats.masteryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm ring-1 ring-border h-[350px]">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Recent Progress</CardTitle>
                </CardHeader>
                <CardContent className="h-full pb-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.deckData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                      />
                      <Bar dataKey="mastered" name="Mastered" fill="#2B7EA1" radius={[2, 2, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
