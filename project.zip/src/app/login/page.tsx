'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

// Hardcoding directly inside the file using verified production credentials
const firebaseConfig = {
  apiKey: "AIzaSyBqLPAw9aSqeDd3FANU1gZ87Cb3sqRwZbc",
  authDomain: "recallify-b638c.firebaseapp.com",
  projectId: "recallify-b638c",
  storageBucket: "recallify-b638c.firebasestorage.app",
  messagingSenderId: "685122638174",
  appId: "1:685122638174:web:3f8e02e7fb5Caea4247cff"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        router.push('/decks');
      }
    } catch (err: any) {
      console.error("Firebase Auth Error:", err);
      // Surface specific Firebase errors for easier debugging
      if (err.code === 'auth/popup-closed-by-user') {
        setError("Sign-in popup was closed before completion.");
      } else if (err.code === 'auth/api-key-not-valid') {
        setError("Firebase API Key is invalid. Please check your console configuration.");
      } else {
        setError(err.message || "An unexpected error occurred during sign-in.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md space-y-8 rounded-xl bg-white p-8 shadow-md text-center">
        <div className="space-y-2">
          <h2 className="text-3xl font-bold text-gray-900 tracking-tight font-headline">Welcome Back</h2>
          <p className="text-sm text-gray-600">Sign in to access your study library</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm font-medium">
            {error}
          </div>
        )}

        <button 
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 rounded-lg border border-gray-300 bg-white px-4 py-3 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <span>Connecting...</span>
            </div>
          ) : (
            <>
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path fill="#EA4335" d="M12 5.04c1.64 0 3.12.56 4.28 1.67l3.2-3.2C17.52 1.58 15 1 12 1 7.35 1 3.4 3.65 1.5 7.5l3.86 3C6.27 7.77 8.9 5.04 12 5.04z"/>
                <path fill="#4285F4" d="M23.5 12.25c0-.82-.07-1.6-.2-2.35H12v4.5h6.46c-.28 1.47-1.12 2.72-2.38 3.56l3.7 2.87c2.16-2 3.72-4.94 3.72-8.58z"/>
                <path fill="#FBBC05" d="M5.36 14.5c-.24-.72-.38-1.49-.38-2.3s.14-1.58.38-2.3L1.5 6.9C.54 8.84 0 11.03 0 12.3s.54 3.46 1.5 5.4l3.86-3z"/>
                <path fill="#34A853" d="M12 23c3.24 0 5.97-1.08 7.96-2.9l-3.7-2.87c-1.03.69-2.34 1.1-4.26 1.1-3.1 0-5.73-2.73-6.64-5.46l-3.86 3C3.4 20.35 7.35 23 12 23z"/>
              </svg>
              <span>Continue with Google</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
