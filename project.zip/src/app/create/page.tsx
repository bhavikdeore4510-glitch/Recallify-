"use client"

import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/layout/Navbar';
import { useDecks } from '@/hooks/use-decks';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Sparkles, BrainCircuit, Type, Loader2, Camera, Upload, Image as ImageIcon, X, ChevronLeft } from 'lucide-react';
import { synthesizeFlashcards } from '@/ai/flows/ai-card-synthesizer';
import { scanNotesForCards } from '@/ai/flows/ai-scan-notes';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export default function CreatePage() {
  const router = useRouter();
  const { toast } = useToast();
  const { addDeck, addCardsToDeck } = useDecks();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [deckName, setDeckName] = useState('');
  const [category, setCategory] = useState('');
  const [notes, setNotes] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleCreateEmpty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deckName) return;
    const deck = addDeck(deckName, category || 'General');
    router.push(`/decks/${deck.id}`);
  };

  const handleAISynthesis = async () => {
    if (!deckName || !notes) return;
    setIsProcessing(true);
    try {
      const result = await synthesizeFlashcards({ notes });
      const deck = addDeck(deckName, category || 'AI Generated');
      addCardsToDeck(deck.id, result.flashcards);
      toast({
        title: "Success!",
        description: `Generated ${result.flashcards.length} cards from your notes.`,
      });
      router.push(`/decks/${deck.id}`);
    } catch (err) {
      console.error("Failed to synthesize", err);
      toast({
        variant: "destructive",
        title: "Synthesis Failed",
        description: "We couldn't process those notes. Please try a shorter snippet.",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Please upload an image smaller than 10MB.",
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScanNotes = async () => {
    if (!deckName || !imagePreview) return;
    setIsProcessing(true);
    try {
      const result = await scanNotesForCards({ photoDataUri: imagePreview });
      const deck = addDeck(deckName, category || 'Visual Scan');
      addCardsToDeck(deck.id, result.flashcards);
      toast({
        title: "Scan Complete",
        description: `Extracted ${result.flashcards.length} cards from your image.`,
      });
      router.push(`/decks/${deck.id}`);
    } catch (err) {
      console.error("Failed to scan notes", err);
      toast({
        variant: "destructive",
        title: "Scan Failed",
        description: "The image couldn't be read. Ensure the text is clear and well-lit.",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container max-w-4xl mx-auto px-4 py-12">
        <header className="mb-10">
          <Button 
            variant="ghost" 
            onClick={() => router.push('/')} 
            className="mb-4 -ml-4 gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ChevronLeft className="w-4 h-4" /> Back to My Decks
          </Button>
          <h1 className="text-4xl font-headline font-bold text-primary mb-2">Build Your Knowledge</h1>
          <p className="text-muted-foreground text-lg">Start by defining your deck then choose how to populate your cards.</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-1 gap-12">
          <section className="space-y-8">
            <Card className="border-none shadow-sm ring-1 ring-border">
              <CardHeader>
                <CardTitle className="font-headline">Deck Details</CardTitle>
                <CardDescription>Give your study deck a title and category.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Deck Name</Label>
                  <Input 
                    id="name" 
                    placeholder="e.g. Modern Physics Final" 
                    value={deckName}
                    onChange={(e) => setDeckName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Input 
                    id="category" 
                    placeholder="e.g. Science" 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="ai" className="w-full">
              <TabsList className="grid w-full grid-cols-3 h-12 bg-white ring-1 ring-border p-1">
                <TabsTrigger value="ai" className="gap-2 data-[state=active]:bg-secondary data-[state=active]:text-primary">
                  <Sparkles className="w-4 h-4" /> AI Text
                </TabsTrigger>
                <TabsTrigger value="scan" className="gap-2 data-[state=active]:bg-secondary data-[state=active]:text-primary">
                  <Camera className="w-4 h-4" /> Scan Notes
                </TabsTrigger>
                <TabsTrigger value="manual" className="gap-2">
                  <Type className="w-4 h-4" /> Manual
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="ai" className="mt-6">
                <Card className="border-none shadow-lg bg-white overflow-hidden">
                  <div className="bg-primary/5 p-4 border-b border-primary/10 flex items-center gap-2">
                    <BrainCircuit className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-primary uppercase tracking-wider">AI Powered Extraction</span>
                  </div>
                  <CardContent className="pt-6 space-y-4">
                    <Label htmlFor="notes">Paste Study Notes or Document Content</Label>
                    <Textarea 
                      id="notes" 
                      placeholder="Paste your textbooks snippets, notes, or lecture transcripts here..."
                      className="min-h-[250px] leading-relaxed"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                    />
                    <Button 
                      className="w-full h-12 gap-2 bg-accent hover:bg-accent/90 shadow-md"
                      disabled={isProcessing || !notes || !deckName}
                      onClick={handleAISynthesis}
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Synthesizing Cards...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5" />
                          Synthesize Flashcards
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="scan" className="mt-6">
                <Card className="border-none shadow-lg bg-white overflow-hidden">
                  <div className="bg-accent/5 p-4 border-b border-accent/10 flex items-center gap-2">
                    <Camera className="w-5 h-5 text-accent" />
                    <span className="text-sm font-medium text-accent uppercase tracking-wider">Visual Note Scanner</span>
                  </div>
                  <CardContent className="pt-6 space-y-6">
                    {!imagePreview ? (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-muted rounded-2xl p-12 text-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all group"
                      >
                        <div className="bg-muted p-4 rounded-full w-16 h-16 mx-auto mb-4 group-hover:bg-accent/10 group-hover:text-accent transition-colors">
                          <Upload className="w-8 h-8" />
                        </div>
                        <h3 className="text-lg font-bold mb-1">Upload Note Image</h3>
                        <p className="text-muted-foreground">JPG, PNG or WEBP (max 10MB)</p>
                      </div>
                    ) : (
                      <div className="relative rounded-2xl overflow-hidden ring-1 ring-border">
                         <div className="absolute top-4 right-4 z-10">
                            <Button 
                              variant="destructive" 
                              size="icon" 
                              className="rounded-full h-8 w-8"
                              onClick={() => setImagePreview(null)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                         </div>
                         <div className="aspect-video relative bg-muted">
                           <Image 
                             src={imagePreview} 
                             alt="Note Preview" 
                             fill 
                             className="object-contain"
                           />
                         </div>
                      </div>
                    )}

                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleImageChange}
                    />

                    <Button 
                      className="w-full h-12 gap-2 bg-primary hover:bg-primary/90 shadow-md"
                      disabled={isProcessing || !imagePreview || !deckName}
                      onClick={handleScanNotes}
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Scanning Notes...
                        </>
                      ) : (
                        <>
                          <ImageIcon className="w-5 h-5" />
                          Scan Image & Generate
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="manual" className="mt-6">
                <Card className="border-none shadow-sm ring-1 ring-border">
                  <CardHeader>
                    <CardTitle className="text-lg">Manual Card Creation</CardTitle>
                    <CardDescription>Create the deck now and add cards one-by-one in the editor.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      variant="outline" 
                      className="w-full h-12 gap-2"
                      onClick={handleCreateEmpty}
                      disabled={!deckName}
                    >
                      Create Empty Deck
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </section>
        </div>
      </main>
    </div>
  );
}
