'use client';

import React, { useEffect, useState } from 'react';
import { auth, db } from './config';
import { FirebaseProvider } from './provider';
import { Loader2 } from 'lucide-react';
import { getApp } from 'firebase/app';

export const FirebaseClientProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="text-muted-foreground font-medium animate-pulse">Loading Recallify...</p>
        </div>
      </div>
    );
  }

  return (
    <FirebaseProvider
      firebaseApp={getApp()}
      firestore={db}
      auth={auth}
    >
      {children}
    </FirebaseProvider>
  );
};
