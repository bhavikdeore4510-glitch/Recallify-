'use client';

import { auth, db } from './config';
import { getApp } from 'firebase/app';

export function initializeFirebase() {
  return { firebaseApp: getApp(), firestore: db, auth };
}

export { auth, db };
export * from './provider';
export * from './client-provider';
export * from './auth/use-user';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './use-memo-firebase';
export * from './error-emitter';
export * from './errors';