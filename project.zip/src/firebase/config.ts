import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBqLPAw9aSqeDd3FANU1gZ87Cb3sqRwZbc",
  authDomain: "recallify-b638c.firebaseapp.com",
  projectId: "recallify-b638c",
  storageBucket: "recallify-b638c.firebasestorage.app",
  messagingSenderId: "685122638174",
  appId: "1:685122638174:web:3f8e02e7fb5Caea4247cff"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
export const facebookProvider = new FacebookAuthProvider();
