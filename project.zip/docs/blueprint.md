# **App Name**: Recallify

## Core Features:

- AI Card Synthesizer: Paste text notes or documents to have the AI tool automatically extract key concepts and generate a set of flashcards.
- Manual Card Builder: Create custom flashcards by entering questions for the front and answers for the back with markdown support.
- The Study Stage: Enter study mode where cards are presented one-by-one, featuring a tap-to-flip mechanism to reveal the answer.
- Active Recall Logging: Rate your level of confidence for each answer to track mastery levels across different decks.
- Deck Management System: Organize flashcards into categorized decks to keep different subjects and study topics separated.
- Retention Dashboard: View a summary of study sessions and see high-level statistics on your current learning progress.

## Style Guidelines:

- Primary color: Deep Ink Blue (#3A4C8B), selected for its association with academic focus and mental clarity.
- Background color: Tainted Frost (#F4F6F8), a slightly cool, desaturated off-white that reduces eye strain during long study sessions.
- Accent color: Cerulean Spark (#2B7EA1), an analogous hue that provides high contrast for call-to-action buttons.
- A sophisticated font pairing using 'Space Grotesk' (sans-serif) for tech-forward headlines and 'Inter' (sans-serif) for maximum legibility in body text and card content.
- Minimalist, thin-line icons representing knowledge, decks, and metrics to maintain a distraction-free environment.
- A card-centric interface with a generous focus on whitespace to ensure users stay concentrated on the task at hand.
- Smooth 3D flip transitions when interacting with flashcards and subtle progress bar fill animations for study metrics.